from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state("zoomed"))
app.title("College")

date1 = StringVar()

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabal = CTkLabel(app, image=imgtemp, text='')
imgLabal.place(relx=0.5, rely=0.5, anchor="center")

def addAttendance():
    for widget in frame2.winfo_children():
        widget.destroy()
    
    add_att_frame =  CTkFrame(frame2, width=530, height=590, fg_color="#e6e1e1")
    add_att_frame.place(x=5, y=5)
    add_att_frame.pack_propagate(False)

    date = DateEntry(add_att_frame, width=75, COMMAND=lambda event1="<<DateEntrySelected>>": loadStudents(date=date.get_date(), event=event1))
    date.bind("<<DateEntrySelected>>", lambda e:loadStudents(date=date.get_date(), event=e))
    date.grid(row=1, column=1, padx=20, pady=(20, 10), columnspan=30)

    CTkLabel(add_att_frame, text_color="#33333d", text="Mark All").grid(row=2, column=1, padx=20, pady=(10, 10))
    cmb_mark_all = CTkComboBox(add_att_frame, width=370, fg_color="white", text_color="#33333d")
    cmb_mark_all.set("-- SELECT --")
    cmb_mark_all.grid(row=2, column=2, pady=(10, 10), columnspan=40)

def loadStudents(date, event=None):
    # date_sel = date.get_date()
    print(date)

# loadStudents()

def modifyAttendance():
    pass

parent_frame = CTkFrame(app, width=800, height=600)
parent_frame.place(relx=0.5, rely=0.5, anchor="center")

frame1 = CTkFrame(parent_frame, width=290, height=600, fg_color="#33333d")
frame1.grid(row=0, column=0, sticky="nswe")

# fc4305, f79502
CTkButton(frame1, width=200, height=30, fg_color="#fc4305", text="Add Attendance", command=addAttendance, font=("Segoe UI", 15, 'bold')).grid(row=1, column=1, padx=20, pady=(40, 10))
CTkButton(frame1, width=200, height=30, fg_color="#fc4305", text="Modify Attendance", command=modifyAttendance, font=("Segoe UI", 15, 'bold')).grid(row=2, column=1, padx=20, pady=(10, 10))

frame2 = CTkFrame(parent_frame, width=533.33, height=600, fg_color="#e6e1e1")
frame2.grid(row=0, column=1, sticky="nswe")

app.mainloop()
