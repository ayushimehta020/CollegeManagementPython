from customtkinter import *
from PIL import Image

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state("zoomed"))
app.title("College")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabal = CTkLabel(app, image=imgtemp, text='')
imgLabal.place(relx=0.5, rely=0.5, anchor="center")

app.mainloop()
