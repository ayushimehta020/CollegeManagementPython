from tkinter import *

def showSelected():
    # Get the indices of all the selected items
    selectedIndices = bigListbox.curselection()
    selectedItems = []
    # Loop over the selected indices and get the values of the selected items
    for index in selectedIndices:
        selectedItems.append(bigListbox.get(index))
    show.config(text=selectedItems)

rootWindow = Tk()

bigListbox = Listbox(rootWindow, selectmode="multiple")
bigListbox.pack()

# Load workstations from file
bigArr=["MYHSS", "MY", "MORE", "Aloysius"]

myIndex = len(bigArr)

for index in range(0, myIndex):
    bigListbox.insert(myIndex, bigArr[index])

Button(rootWindow, text='Send', command=showSelected).pack(pady=20)

show = Label(rootWindow)
show.pack()

rootWindow.mainloop()