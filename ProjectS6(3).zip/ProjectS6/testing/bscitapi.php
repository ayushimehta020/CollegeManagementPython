<?php
    $con = mysqli_connect("127.0.0.1", "root", "", "student");
    $action = $_POST['action'];
    if ($action == "Select")
    {
        $id = $_POST['id'];
        $sql = "select * from `stud` where id='$id'";
        $res = mysqli_query($con, $sql);
        if (mysqli_num_rows($res) > 0)
        {
            $rows = mysqli_fetch_assoc($res);
            $ar1 = array();
            array_push($ar1, $rows['enr'], $rows['name'], $rows['email'], $rows['password'], $rows['contact'], $rows['course']);
            echo json_encode(["data"=>$ar1[0], "name"=>$ar1[1], "email"=>$ar1[2], "pwd"=>$ar1[3], "mob_no"=>$ar1[4], "course"=>$ar1[5]]);
        }
        else
        {
            echo json_encode(["data"=>"0"]);
        }
    }
    else if ($action == "Insert")
    {
        $enr = $_POST['enr'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['pwd'];
        $mob = $_POST['mob'];
        $course = $_POST['course'];
        $sql = "insert into `stud`(`enr`, `name`, `email`, `password`, `contact`, `course`) values('$enr', '$name', '$email', '$password', '$mob', '$course')";
        $res = mysqli_query($con, $sql);
        if (mysqli_affected_rows($con) == 1)
        {
            echo json_encode(["data"=>"1"]);
        }
        else
        {
            echo json_encode(["data"=>"0"]);
        }
    }
    else if ($action == "Update")
    {
        $id = $_POST['id'];
        $enr = $_POST['enr'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['pwd'];
        $mob = $_POST['mob'];
        $course = $_POST['course'];
        $sql = "update `stud` set `enr`='$enr', `name`='$name', `email`='$email', `password`='$password', `contact`='$mob', `course`='$course' where `id`=$id";
        $res = mysqli_query($con, $sql);
        if (mysqli_affected_rows($con) == 1)
        {
            echo json_encode(["data"=>"1"]);
        }
        else
        {
            echo json_encode(["data"=>"0"]);
        }
    }
    else if ($action == "Delete")
    {
        $id = $_POST['id'];
        $sql = "delete from `stud` where `id`=$id";
        $res = mysqli_query($con, $sql);
        if (mysqli_affected_rows($con) == 1)
        {
            echo json_encode(["data"=>"1"]);
        }
        else
        {
            echo json_encode(["data"=>"0"]);
        }
    }
?>