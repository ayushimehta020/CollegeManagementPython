from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry
import mysql.connector
from CTkMessagebox import CTkMessagebox
import datetime

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

index = 0
tr = 0
gen = StringVar()
var1 = StringVar()
var2 = StringVar()
var3 = StringVar()
var4 = StringVar()
dept1 = []
dept2 = []

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def addToList():
    for x in checkboxes:
        if x._check_state:
            dept2.append(x._text)
    return dept2

def searchID():
    global dept1
    idStr = txtid.get()
    id = str(idStr) if idStr.isdecimal() else None

    if id != None:
        sql = "SELECT * FROM faculty WHERE faculty_id=%s"
        values = (id,)
        mycursor.execute(sql, values)
        res = mycursor.fetchall()

        clear()
        if len(res) > 0:
            for x in res:
                txtid.insert(0, x[0])
                txtnm.insert(0, x[1])
                dtDob.set_date(x[2])
                txtage.insert(0, x[3])
                gen.set("Female") if x[4] == "F" else gen.set("Male")
                txtemail.insert(0, x[5])
                txtmob.insert(0, x[6])
                txtexp.insert(0, x[7])
                dept1 = x[8].split(",")
                checked(dept1)
                txtsal.insert(0, x[9])
                dtJoin.set_date(x[10])
                txtqual.insert(0, x[11])

def update():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None

    if id != None:
        name = txtnm.get()
        dob = dtDob.get_date()
        age = txtage.get()
        gender = gen.get()
        gen1 = "M" if gender == "Male" else "Female"
        email = txtemail.get()
        mob_no = txtmob.get()
        exp = txtexp.get()
        # print(dept1)
        # checked(dept1)
        dept1 = addToList()
        print(dept1)
        dept = ','.join(dept1)
        print(dept)
        salary = txtsal.get()
        join_date = dtJoin.get_date()
        qual = txtqual.get()

        if name.strip() and dob and age.strip().isnumeric() and gen1.strip() and email.strip() and mob_no.strip().isnumeric() and exp.strip() and dept.strip() and salary.strip().isnumeric() and join_date and qual.strip():
            sql = "UPDATE faculty SET name=%s, dob=%s, age=%s, gender=%s, email=%s, mob_no=%s, experience=%s, department=%s, salary=%s, joining_date=%s, qualification=%s WHERE faculty_id=%s"
            values = (name, dob, age, gen1, email, mob_no, exp, dept, salary, join_date, qual, id)
            mycursor.execute(sql, values)
            db.commit()

            if mycursor.rowcount > 0:
                CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record updated successfully!")
            else:
                CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be updated!")
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid values!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid ID!")

def delete():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None

    if id != None:
        sql = "DELETE FROM faculty WHERE faculty_id=%s"
        values = (id,)
        mycursor.execute(sql, values)
        db.commit()

        if mycursor.rowcount > 0:
            CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record deleted successfully!")
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be deleted!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid ID!")

def first():
    pass

def next():
    pass

def prev():
    pass

def last():
    pass

def load():
    global index
    index = 0
    records()

def clear():
    txtid.delete(0, END)
    txtnm.delete(0, END)
    dtDob.set_date(datetime.date.today())
    txtage.delete(0, END)
    gen.set("Male")
    txtemail.delete(0, END)
    txtmob.delete(0, END)
    txtexp.delete(0, END)
    for x in checkboxes:
        x.deselect()
    txtsal.delete(0, END)
    dtJoin.set_date(datetime.date.today())
    txtqual.delete(0, END)

def records():
    sql = "SELECT * FROM faculty"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    global tr
    tr = len(res) - 1
    global index

    clear()
    if len(res) > 0:
        txtid.insert(0, res[index][0])
        txtnm.insert(0, res[index][1])
        dtDob.set_date(res[index][2])
        txtage.insert(0, res[index][3])
        gen.set("Male") if res[index][4] == "M" else gen.set("Female")
        txtemail.insert(0, res[index][5])
        txtmob.insert(0, res[index][6])
        txtexp.insert(0, res[index][7])
        checked(res[index][8].split(","))
        txtsal.insert(0, res[index][9])
        dtJoin.set_date(res[index][10])
        txtqual.insert(0, res[index][11])
    else:
        updateBtn._state = DISABLED
        deleteBtn._state = DISABLED
        firstBtn._state = DISABLED
        nextBtn._state = DISABLED
        prevBtn._state = DISABLED
        lastBtn._state = DISABLED

def query():
    sql = "SELECT * FROM faculty"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    return len(res)

def checked(dept):
    for x in dept:
        if x == chkVal1._text:
            chkVal1.select()
        elif x == chkVal2._text:
            chkVal2.select()
        elif x == chkVal3._text:
            chkVal3.select()
        elif x == chkVal4._text:
            chkVal4.select()
        # if x == chkVal1._text:
        #     chkVal1
        # elif x == chkVal2._text:
        #     chkVal2._check_state = True

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

txtid = CTkEntry(frm, placeholder_text="Enter ID To Search")
txtid.grid(row=1, column=1, pady=(15, 5), padx=(30, 20), columnspan=4, sticky="we")

CTkButton(frm, text="Search", command=searchID).grid(row=2, column=1, padx=(30, 20), pady=(5, 0), columnspan=4, sticky="we")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=3, column=1, padx=(30, 12), pady=(10, 10), sticky="w", columnspan=2)
txtnm = CTkEntry(frm, width=220)
txtnm.grid(row=3, column=3, pady=(10, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Date of Birth").grid(row=4, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
dtDob = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=33, background="blue", foreground="white", fieldbackground="black")
dtDob.grid(row=4, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Age").grid(row=5, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtage = CTkEntry(frm, width=220)
txtage.grid(row=5, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Gender").grid(row=6, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
rbMale = CTkRadioButton(frm, text="Male", value="Male", radiobutton_height=14, radiobutton_width=14, border_width_checked=3, variable=gen, border_width_unchecked=2)
rbMale.grid(row=6, column=3, pady=(0, 10))

rbFemale = CTkRadioButton(frm, text="Female", value="Female", radiobutton_height=14, border_width_checked=3, radiobutton_width=14, variable=gen, border_width_unchecked=2)
rbFemale.grid(row=6, column=4, pady=(0, 10))

CTkLabel(frm, text="Enter Email").grid(row=7, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtemail = CTkEntry(frm, width=220)
txtemail.grid(row=7, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Mobile Number").grid(row=8, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtmob = CTkEntry(frm, width=220)
txtmob.grid(row=8, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Experience").grid(row=9, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtexp = CTkEntry(frm, width=220)
txtexp.grid(row=9, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Department").grid(row=10, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
chkVal1 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="IT")
chkVal1.grid(row=10, column=3, pady=(0, 10), padx=(10, 20))
chkVal2 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Commerce")
chkVal2.grid(row=10, column=4, pady=(0, 10), padx=(10, 20))
chkVal3 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Management")
chkVal3.grid(row=11, column=3, pady=(0, 10), padx=(10, 20))
chkVal4 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Other")
chkVal4.grid(row=11, column=4, pady=(0, 10), padx=(10, 20))

checkboxes = [chkVal1, chkVal2, chkVal3, chkVal4]

CTkLabel(frm, text="Enter Salary").grid(row=12, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtsal = CTkEntry(frm, width=220)
txtsal.grid(row=12, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Joining Date").grid(row=13, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
dtJoin = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=33, background="blue", foreground="white", fieldbackground="black")
dtJoin.grid(row=13, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Qualification").grid(row=14, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtqual = CTkEntry(frm, width=220)
txtqual.grid(row=14, column=3, pady=(0, 20), padx=(10, 20), columnspan=2)

updateBtn = CTkButton(frm, text="Update", width=210, fg_color="#d68d02", hover_color="#a16a02", command=update)
updateBtn.grid(row=15, column=1, padx=(30, 6), pady=(15, 5), columnspan=2)
deleteBtn = CTkButton(frm, text="Delete", width=210, fg_color="red", hover_color="#a30202", command=delete)
deleteBtn.grid(row=15, column=3, padx=6, pady=(15, 5), columnspan=2)

firstBtn = CTkButton(frm, text="FIRST", width=100, command=first)
firstBtn.grid(row=16, column=1, padx=(30, 10), pady=(5, 10))
nextBtn = CTkButton(frm, text="NEXT", width=100, command=next)
nextBtn.grid(row=16, column=2, padx=(13, 10), pady=(5, 10))
prevBtn = CTkButton(frm, text="PREV", width=100, command=prev)
prevBtn.grid(row=16, column=3, padx=(5, 0), pady=(5, 10))
lastBtn = CTkButton(frm, text="LAST", width=100, command=last)
lastBtn.grid(row=16, column=4, padx=(0, 6), pady=(5, 10))

app.after(100, load)
app.mainloop()