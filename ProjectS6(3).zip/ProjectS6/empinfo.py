import subprocess
import mysql.connector
import customtkinter as ctk
from tkinter import ttk, StringVar,messagebox
from PIL import Image
from customtkinter import CTkImage
from PIL import Image, ImageTk
from tkcalendar import DateEntry
from tkinter import Canvas, StringVar
from tkcalendar import DateEntry 

class FullScreenApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window Settings
        self.title("Technova Solutions")
        self.grid_columnconfigure(0, weight=1)
        self.after(0, lambda: self.state('zoomed'))
        self.bind("<Escape>", lambda e: self.exit_app())

        # Load the background image
        self.background_image = Image.open("bg_1.jpg")
        self.bg_image = CTkImage(
            light_image=self.background_image,
            size=(self.winfo_screenwidth(), self.winfo_screenheight())
        )
        self.bg_label = ctk.CTkLabel(self, image=self.bg_image, text="")
        self.bg_label.place(relx=0.5, rely=0.5, anchor="center")

        # Parent frame
        self.parent_frame = ctk.CTkFrame(self, width=800, height=600)
        self.parent_frame.place(relx=0.5, rely=0.5, anchor="center")

        # Child frame 1 (1/3 of the parent width)
        self.frame1 = ctk.CTkFrame(self.parent_frame, width=266.67, height=600, fg_color="#4682B1")
        self.frame1.grid(row=0, column=0, sticky="nswe")

        # Add a title in frame1
        self.title_label = ctk.CTkLabel(self.frame1, text="Technova Solutions", font=("Verdana", 25))
        self.title_label.pack(pady=20, padx=25)

        # Search by department button
        self.info_button = ctk.CTkButton(
            self.frame1, text="Search By Department", command=self.show_employee_info,
            width=266, height=50, font=("Verdana", 15), fg_color="#00274D"
        )
        self.info_button.pack(pady=(10,20))
        
        # Attendance
        self.info_button = ctk.CTkButton(
            self.frame1, text="Attendance", command=self.show_attendance_management,
            width=266, height=50, font=("Verdana", 15), fg_color="#00274D"
        )
        self.info_button.pack(pady=(10,20))
        
        # Payroll Management
        self.info_button = ctk.CTkButton(
            self.frame1, text="Payroll", command=self.show_employee_info,
            width=266, height=50, font=("Verdana", 15), fg_color="#00274D"
        )
        self.info_button.pack(pady=(10,20))
        
        # Add three links at the bottom-left of frame1 with spacing
        self.modify_employee_link = ctk.CTkLabel(
            self.frame1, text="Modify Employee", text_color="white", cursor="hand2", font=("Verdana", 15)
        )
        self.modify_employee_link.place(relx=0.05, rely=0.95, anchor="sw")
        self.modify_employee_link.bind("<Button-1>", lambda e: self.redirect_to_modifyemp("modifyemp.py"))

        self.view_employee_link = ctk.CTkLabel(
            self.frame1, text="View Employee", text_color="white", cursor="hand2", font=("Verdana", 15)
        )
        self.view_employee_link.place(relx=0.05, rely=0.89, anchor="sw")
        self.view_employee_link.bind("<Button-1>", lambda e: self.redirect_to_viewemp("viewemp.py"))

        self.add_employee_link = ctk.CTkLabel(
            self.frame1, text="Add Employee", text_color="white", cursor="hand2", font=("Verdana", 15)
        )
        self.add_employee_link.place(relx=0.05, rely=0.83, anchor="sw")
        self.add_employee_link.bind("<Button-1>", lambda e: self.redirect_to_addemp("addemp.py"))


        # Child frame 2 (2/3 of the parent width)
        self.frame2 = ctk.CTkFrame(self.parent_frame, width=533.33, height=600, fg_color="#98AFC7")
        self.frame2.grid(row=0, column=1, sticky="nswe")

        # Connect to MySQL database
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="employee"
        )
        self.cursor = self.conn.cursor()

        # Create a style for Treeview (table)
        self.style = ttk.Style()
        self.style.configure("Custom.Treeview",
                            background="#D3D3D3",
                            foreground="black",
                            font=("Verdana", 10),
                            padding=(7)
                        )
        
        # Additional styles for table header
        self.style.configure("Custom.Treeview.Heading",
                            font=("Verdana", 12, "bold"),
                            background="#D3D3D3",
                            foreground="Black",
                            padding=(10)
                        )

    def show_employee_info(self):
        # Clear frame2
        for widget in self.frame2.winfo_children():
            widget.destroy()

        # Add a new frame for search and table
        info_frame = ctk.CTkFrame(self.frame2, width=530, height=590, fg_color="white")
        info_frame.place(x=5, y=5)  # Use place to position the frame

        #combobox
        self.search_var = StringVar()
        self.search_entry = ttk.Combobox(info_frame, textvariable=self.search_var, font=("Verdana", 10))
        self.search_entry['values'] = self.get_departments()
        self.search_entry.place(x=35, y=21, width=468,height="30")
        self.search_entry.bind("<<ComboboxSelected>>", self.filter_table)
        
        placeholder_text = "  Search department"
        self.search_entry.set(placeholder_text)
        
        # Load the image and create a CTkImage
        search_icon = Image.open("search.png")
        search_icon_ctk = CTkImage(light_image=search_icon, size=(24, 24))

        # Create a label with the CTkImage
        search_label = ctk.CTkLabel(info_frame, image=search_icon_ctk, text="", width=30, height=25)
        search_label.place(x=450, y=23)
        
        
        # Table
        self.table = ttk.Treeview(info_frame, columns=("ID", "Name", "Department"), show="headings", height=23, style="Custom.Treeview")
        self.table.heading("ID", text="ID")
        self.table.heading("Name", text="Name")
        self.table.heading("Department", text="Department")
        self.table.column("ID", width=100, anchor="center")
        self.table.column("Name", width=200, anchor="center")
        self.table.column("Department", width=150, anchor="center")
        self.table.place(x=35, y=70)
        
        # Add border to each cell by setting the style
        for col in self.table["columns"]:
            self.table.column(col, anchor="center", width=150, minwidth=100, stretch=1)


        # Populate the table with initial data
        self.populate_table(self.get_all_employees())

    def get_all_employees(self):
        """Fetch all employees from the database."""
        query = "SELECT emp_id,name,dept FROM addemp"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def get_departments(self):
        """Fetch distinct departments from the database."""
        query = "SELECT DISTINCT dept FROM addemp"
        self.cursor.execute(query)
        return [row[0] for row in self.cursor.fetchall()]

    def populate_table(self, data):
        """Populate the table with data."""
        for item in self.table.get_children():
            self.table.delete(item)
        for record in data:
            self.table.insert("", "end", values=record)

    def filter_table(self, event=None):
        """Filter table based on the selected department."""
        selected_department = self.search_var.get()
        query = "SELECT emp_id,name,dept FROM addemp WHERE dept = %s"
        self.cursor.execute(query, (selected_department,))
        filtered_data = self.cursor.fetchall()
        self.populate_table(filtered_data)
        
    def redirect_to_addemp(self, file_name):
        try:
            subprocess.Popen(["python", "addemp.py"])
        except Exception as e:
            print(f"Error opening {file_name}: {e}")

    def redirect_to_viewemp(self, file_name):
        try:
            subprocess.Popen(["python", "viewemp.py"])
        except Exception as e:
            print(f"Error opening {file_name}: {e}")

    def redirect_to_modifyemp(self, file_name):
        try:
            subprocess.Popen(["python", "modifyemp.py"])
        except Exception as e:
            print(f"Error opening {file_name}: {e}")

# Attendance management
    def show_attendance_management(self):
        # Clear frame2
        for widget in self.frame2.winfo_children():
            widget.destroy()

        # Add a new frame for attendance management
        self.attendance_frame = ctk.CTkFrame(self.frame2, width=530, height=590, fg_color="white")  # Correctly assign it to self
        self.attendance_frame.place(x=5, y=5)

        # Title for attendance management
        title_label = ctk.CTkLabel(self.attendance_frame, text="Attendance Management", font=("Verdana", 20), text_color="black")
        title_label.place(x=140, y=15)

        self.selected_date = StringVar()
        date_dropdown = DateEntry(
            self.attendance_frame,
            textvariable=self.selected_date,
            width=42,
            height=8,
            font=("Verdana", 12),
            date_pattern="yyyy-mm-dd",
            state="readonly"
        )
        date_dropdown.place(x=38, y=60)

        # Frame to contain the table and scrollbar
        table_frame = ctk.CTkFrame(self.attendance_frame, width=450, height=300)
        table_frame.place(x=35, y=100)

        # Scrollable Canvas for the table
        canvas = Canvas(table_frame, width=450, height=415)
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ctk.CTkFrame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Populate the table with employee data
        self.populate_employee_attendance_table(scrollable_frame)

        # Mark attendance button
        mark_button = ctk.CTkButton(
            self.attendance_frame,
            text="Mark Attendance",
            command=self.mark_attendance,
            font=("Verdana", 14),
            fg_color="#00274D",
            width=220,
            height=40
        )
        mark_button.place(x=35, y=535)

        # View attendance button
        view_button = ctk.CTkButton(
            self.attendance_frame,
            text="View Attendance",
            command=self.view_attendance,
            font=("Verdana", 14),
            fg_color="#00274D",
            width=220,
            height=40
        )
        view_button.place(x=260, y=535)

        
    def view_attendance(self):
        """View attendance for the selected date."""
        date = self.selected_date.get()
        if not date:
            ctk.CTkLabel(self.attendance_frame, text="Please select a date.", text_color="red", font=("Verdana", 12)).place(x=35, y=120)
            return

        # Clear the frame for displaying attendance data
        for widget in self.attendance_frame.winfo_children():
            widget.place_forget()

        # Fetch attendance for the selected date from the database
        query = """
        SELECT attendance.emp_id, addemp.name, attendance.status 
        FROM attendance 
        INNER JOIN addemp ON attendance.emp_id = addemp.emp_id 
        WHERE attendance.date = %s
        """
        self.cursor.execute(query, (date,))
        attendance_data = self.cursor.fetchall()

        if not attendance_data:
            # No records found for the selected date
            ctk.CTkLabel(self.attendance_frame, text="No record found.", text_color="red", font=("Verdana", 12)).place(x=35, y=120)
        else:
            # Show attendance data in a table
            self.show_attendance(attendance_data)
  
    def populate_employee_attendance_table(self, parent_frame):
        """Populate the employee attendance table with headings and data."""
        for widget in parent_frame.winfo_children():
            widget.destroy()

        # Add table headings
        headings = ["ID", "Name", "Attendance"]
        for col_index, heading in enumerate(headings):
            heading_label = ctk.CTkLabel(parent_frame, text=heading, font=("Verdana", 15, "italic","bold"))
            heading_label.grid(row=0, column=col_index, padx=5, pady=5)

        # Fetch employee data from the database
        query = "SELECT emp_id, name FROM addemp"
        self.cursor.execute(query)
        employees = self.cursor.fetchall()

        self.attendance_status = {}  # Dictionary to store the status for each employee

        # Populate the table with employee data
        for row_index, (emp_id, name) in enumerate(employees, start=1):  # Start from 1 to leave row 0 for headings
            # Display Employee ID
            emp_id_label = ctk.CTkLabel(parent_frame, text=emp_id, font=("Verdana", 12))
            emp_id_label.grid(row=row_index, column=0, padx=20, pady=5)

            # Display Employee Name
            name_label = ctk.CTkLabel(parent_frame, text=name, font=("Verdana", 12))
            name_label.grid(row=row_index, column=1, padx=30, pady=5)

            # Create a StringVar for each employee's attendance status
            self.attendance_status[emp_id] = StringVar()

            # Present Radio Button
            present_button = ctk.CTkRadioButton(
                parent_frame,
                text="Present",
                variable=self.attendance_status[emp_id],
                value="Present",
                font=("Verdana", 12),
            )
            present_button.grid(row=row_index, column=2, padx=5, pady=3, sticky="nsew")

            # Absent Radio Button
            absent_button = ctk.CTkRadioButton(
                parent_frame,
                text="Absent",
                variable=self.attendance_status[emp_id],
                value="Absent",
                font=("Verdana", 12),
            )
            absent_button.grid(row=row_index, column=3, padx=5, pady=3, sticky="nsew")
            
            # leave Radio Button
            leave_button = ctk.CTkRadioButton(
                parent_frame,
                text="leave",
                variable=self.attendance_status[emp_id],
                value="leave",
                font=("Verdana", 12),
            )
            leave_button.grid(row=row_index, column=4, padx=5, pady=3, sticky="nsew")
    
    

        
        
    def mark_attendance(self):
        """Mark attendance for employees."""
        selected_date = self.selected_date.get()
        
        # Check if a date is selected
        if not selected_date:
            messagebox.showwarning("Warning", "Please select a date.")
            return

        # Check if attendance for the selected date already exists
        query = "SELECT COUNT(*) FROM attendance WHERE date = %s"
        self.cursor.execute(query, (selected_date,))
        attendance_count = self.cursor.fetchone()[0]

        if attendance_count > 0:
            messagebox.showwarning("Warning", f"Attendance for {selected_date} has already been marked.")
            return

        all_attendance_marked = True  # Flag to check if all attendance is marked

        for emp_id, attendance_var in self.attendance_status.items():
            attendance_value = attendance_var.get()

            # Check if attendance is selected
            if attendance_value == "":
                messagebox.showwarning("Warning", f"Please select attendance for employee ID {emp_id}.")
                all_attendance_marked = False  # Set flag to False if any attendance is not marked
                break  # Exit the loop as we found an unmarked attendance

            # Save attendance to the database
            query = "INSERT INTO attendance (emp_id, date, status) VALUES (%s, %s, %s)"
            self.cursor.execute(query, (emp_id, selected_date, attendance_value))

        if all_attendance_marked:
            self.conn.commit()
            messagebox.showinfo("Success", "Attendance marked successfully.")



    def exit_app(self):
        self.conn.close()
        self.destroy()


if __name__ == "__main__":
    app = FullScreenApp()
    app.mainloop()