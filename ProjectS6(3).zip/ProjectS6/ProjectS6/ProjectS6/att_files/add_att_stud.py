from customtkinter import *
from PIL import Image
import mysql.connector
from CTkMessagebox import CTkMessagebox
from tkcalendar import DateEntry

app = CTk()
app.attributes("-zoomed", True)
app.title("College Attendance Management")

# Database connection
db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def mark_attendance():
    selected_date = date_entry.get_date()
    attendance_data = {}
    
    for student_id, attendance_var in attendance_vars.items():
        attendance_value = attendance_var.get()
        if attendance_value:
            attendance_data[student_id] = attendance_value

    if not attendance_data:
        CTkMessagebox(app, message="Please select attendance for at least one student.")
        return

    for student_id, status in attendance_data.items():
        sql = "INSERT INTO attendance (student_id, date, status) VALUES (%s, %s, %s)"
        mycursor.execute(sql, (student_id, selected_date, status))
    
    db.commit()
    CTkMessagebox(app, message="Attendance marked successfully!")

def load_students():
    for widget in frame.winfo_children():
        widget.destroy()

    global attendance_vars
    attendance_vars = {}

    date_label = CTkLabel(frame, text="Select Date:")
    date_label.grid(row=0, column=0, padx=10, pady=10)

    global date_entry
    date_entry = DateEntry(frame, date_pattern="yyyy-mm-dd")
    date_entry.grid(row=0, column=1, padx=10, pady=10)

    CTkButton(frame, text="Load Students", command=display_students).grid(row=0, column=2, padx=10, pady=10)

def display_students():
    sql = "SELECT id, name FROM students"
    mycursor.execute(sql)
    students = mycursor.fetchall()

    for index, (student_id, name) in enumerate(students):
        attendance_vars[student_id] = StringVar()
        CTkLabel(frame, text=name).grid(row=index + 1, column=0, padx=10, pady=5)
        CTkRadioButton(frame, text="Present", variable=attendance_vars[student_id], value="Present").grid(row=index + 1, column=1)
        CTkRadioButton(frame, text="Absent", variable=attendance_vars[student_id], value="Absent").grid(row=index + 1, column=2)
        CTkRadioButton(frame, text="Leave", variable=attendance_vars[student_id], value="Leave").grid(row=index + 1, column=3)

    CTkButton(frame, text="Mark Attendance", command=mark_attendance).grid(row=len(students) + 1, column=0, columnspan=4, pady=10)

frame = CTkFrame(app)
frame.pack(pady=20)

load_students()
app.mainloop()
