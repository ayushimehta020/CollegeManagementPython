from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry
from CTkMessagebox import CTkMessagebox
import mysql.connector
import datetime

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

gen = StringVar(value="Male")
dt1 = datetime.date.today()

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def insert():
    name = txtnm.get()
    dob = dtDob.get_date()
    age = txtage.get()
    gender = gen.get()
    email = txtemail.get()
    mobile = txtmob.get()
    exp = txtexp.get()
    chkDept = isChecked()
    chkDeptStr = ','.join(chkDept)
    salary = txtsal.get()
    join_date = dtJoin.get_date()
    qual = txtqual.get()

    if errorLbl._text == "" and name.strip() and dob and age.strip().isnumeric() and gender and email.strip() and len(mobile.strip()) == 10 and mobile.strip().isnumeric() and exp.strip() and chkDeptStr.strip() and salary.strip().isnumeric() and join_date and qual.strip():
        gen1 = "F" if gender == "Female" else "Male"
        sql = "INSERT INTO faculty(name, dob, age, gender, email, mob_no, experience, department, salary, joining_date, qualification) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        values = (name, dob, age, gen1, email, mobile, exp, chkDeptStr, salary, join_date, qual)
        mycursor.execute(sql, values)
        db.commit()
        if mycursor.rowcount > 0:
            CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record added successfully!")
            clear()
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be added!")
            clear()
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Please enter valid values!")

def clear():
    txtnm.delete(0,END)
    dtDob.set_date(dt1)
    txtage.delete(0,END)
    gen.set("Male")
    txtemail.delete(0,END)
    txtmob.delete(0,END)
    txtexp.delete(0,END)
    clearCheckbox()
    txtsal.delete(0,END)
    dtJoin.set_date(dt1)
    txtqual.delete(0,END)
    errorLbl.configure(text="")

def clearCheckbox():
    for checkbox in checkboxes:
        if checkbox.get() == 1:
            checkbox.deselect()

def isChecked():
    chkDept = []
    for checkbox in checkboxes:
        if checkbox.get() == 1:
            chkDept.append(checkbox._text)
    return chkDept

def keyupAge(event):
    age = txtage.get()

    if not age.isnumeric():
        errorLbl.configure(text="Please enter only integer!")
    else:
        errorLbl.configure(text="")

def keyupMob(event):
    mobile = txtmob.get()

    if not mobile.isnumeric():
        errorLbl.configure(text="Please enter only integer!")
    else:
        errorLbl.configure(text="")

def keyupSal(event):
    salary = txtsal.get()

    if not salary.isnumeric():
        errorLbl.configure(text="Please enter only integer!")
    else:
        errorLbl.configure(text="")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=1, column=1, padx=(30, 12), pady=(30, 10), sticky="w")
txtnm = CTkEntry(frm, width=220)
txtnm.grid(row=1, column=2, pady=(30, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Date of Birth").grid(row=2, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
dtDob = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=33, background="blue", foreground="white", fieldbackground="black", maxdate=dt1)
dtDob.grid(row=2, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Age").grid(row=3, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtage = CTkEntry(frm, width=220)
txtage.bind("<KeyRelease>", keyupAge)
txtage.grid(row=3, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Gender").grid(row=4, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
rbMale = CTkRadioButton(frm, text="Male", value="Male", radiobutton_height=14, radiobutton_width=14, border_width_checked=3, variable=gen, border_width_unchecked=2)
rbMale.grid(row=4, column=2, pady=(0, 10))

rbFemale = CTkRadioButton(frm, text="Female", value="Female", radiobutton_height=14, border_width_checked=3, radiobutton_width=14, variable=gen, border_width_unchecked=2)
rbFemale.grid(row=4, column=3, pady=(0, 10))

CTkLabel(frm, text="Enter Email").grid(row=5, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtemail = CTkEntry(frm, width=220)
txtemail.grid(row=5, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Mobile Number").grid(row=6, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtmob = CTkEntry(frm, width=220)
txtmob.bind("<KeyRelease>", keyupMob)
txtmob.grid(row=6, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Experience").grid(row=7, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtexp = CTkEntry(frm, width=220)
txtexp.grid(row=7, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Department").grid(row=8, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
chkVal1 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="IT")
chkVal1.grid(row=8, column=2, pady=(0, 10), padx=(10, 20))
chkVal2 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Commerce")
chkVal2.grid(row=9, column=2, pady=(0, 10), padx=(10, 20))
chkVal3 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Management")
chkVal3.grid(row=10, column=2, pady=(0, 10), padx=(10, 20))
chkVal4 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Other")
chkVal4.grid(row=11, column=2, pady=(0, 10), padx=(10, 20))
checkboxes = [chkVal1, chkVal2, chkVal3, chkVal4]

CTkLabel(frm, text="Enter Salary").grid(row=12, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtsal = CTkEntry(frm, width=220)
txtsal.bind('<KeyRelease>', keyupSal)
txtsal.grid(row=12, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Joining Date").grid(row=13, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
dtJoin = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=33, background="blue", foreground="white", fieldbackground="black", maxdate=dt1)
dtJoin.grid(row=13, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Qualification").grid(row=14, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtqual = CTkEntry(frm, width=220)
txtqual.grid(row=14, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

errorLbl = CTkLabel(frm, text="", text_color="#fa3939")
errorLbl.grid(row=15, column=1, padx=(10, 20), pady=(0, 10), columnspan=4)

CTkButton(frm, text="Insert", width=210, command=insert).grid(row=16, column=1, padx=(30, 6), pady=(0, 20))
CTkButton(frm, text="Clear", width=210, fg_color="red", hover_color="#a30202", command=clear).grid(row=16, column=2, padx=6, pady=(0, 20), columnspan=2)

app.mainloop()