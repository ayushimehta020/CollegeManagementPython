import mysql.connector
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox

app = ctk.CTk()
app.geometry("400x400")

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

mydb = mysql.connector.connect(host="localhost", user="root", password="", database="bscit")
mycursor = mydb.cursor()

tr = 0
index = 0

def searchID():
    id = txtid.get()
    sql = "select * from info where id=%s"
    values = (id,)
    mycursor.execute(sql, values)
    myresult = mycursor.fetchall()
    txtfnm.delete(0, ctk.END)
    txtlnm.delete(0, ctk.END)
    txtemail.delete(0, ctk.END)
    if len(myresult) > 0:
        for x in myresult:
            txtfnm.insert(0, x[1])
            txtlnm.insert(0, x[2])
            txtemail.insert(0, x[3])
    else:
        txtid.delete(0, ctk.END)
        CTkMessagebox(title="Modify", message="No Records Found!", icon="cancel", icon_size=(30, 30), width=100, height=80)

def load():
    global index
    index = 0
    records()

def updateRec():
    id = txtid.get()
    fnm = txtfnm.get()
    lnm = txtlnm.get()
    email = txtemail.get()
    
    if fnm.strip() and lnm.strip() and email.strip():
        sql = "update info set firstname=%s, lastname=%s, email=%s where id=%s"
        values = (fnm, lnm, email, id)
        mycursor.execute(sql, values)
        mydb.commit()
        if mycursor.rowcount > 0:
            CTkMessagebox(title="Modify", message="Record Updated Successfully!", icon="check", icon_size=(30, 30), width=100, height=80)
        else:
            CTkMessagebox(title="Modify", message="Record Cannot Be Updated!", icon="cancel", icon_size=(30, 30), width=100, height=80)
    else:
        CTkMessagebox(title="Modify", message="Enter Valid Values!", icon="cancel", icon_size=(30, 30), width=100, height=80)

def deleteRec():
    id = txtid.get()
    if id.strip():
        sql = "delete from info where id=%s"
        values = (id,)
        mycursor.execute(sql, values)
        mydb.commit()
        if mycursor.rowcount > 0:
            CTkMessagebox(title="Modify", message="Record Deleted Successfully!", icon="check", icon_size=(30, 30), width=100, height=80)
            
            prevRec()
        else:
            CTkMessagebox(title="Modify", message="Record Cannot Be Deleted!", icon="cancel", icon_size=(30, 30), width=100, height=80)
    else:
        CTkMessagebox(title="Modify", message="Enter Valid Values!", icon="cancel", icon_size=(30, 30), width=100, height=80)

def records():
    sql = "select * from info"
    mycursor.execute(sql)
    myresult = mycursor.fetchall()
    global tr
    tr = len(myresult) - 1
    global index
    txtid.delete(0,ctk.END)
    txtfnm.delete(0,ctk.END)
    txtlnm.delete(0,ctk.END)
    txtemail.delete(0,ctk.END)
    if len(myresult) > 0:
        txtid.insert(0, myresult[index][0])
        txtfnm.insert(0, myresult[index][1])
        txtlnm.insert(0, myresult[index][2])
        txtemail.insert(0, myresult[index][3])
    else:
        updateBtn.configure(state=ctk.DISABLED)
        deleteBtn.configure(state=ctk.DISABLED)
        firstRecBtn.configure(state=ctk.DISABLED)
        nextRecBtn.configure(state =ctk.DISABLED)
        prevRecBtn.configure(state=ctk.DISABLED)
        lastRecBtn.configure(state=ctk.DISABLED)

def query():
    sql = "select * from info"
    mycursor.execute(sql)
    myresult = mycursor.fetchall()
    return len(myresult)

"""
private void btnNext_Click(object sender, EventArgs e)
{
    if (tr > ind)
    {
        ind++;
        records();
    }
}

private void btnPrev_Click(object sender, EventArgs e)
{
    if (ind > 0)
    {
        ind--;
        records();
    }
}
"""

def firstRec():
    rs = query()
    global index
    # index = 0
    if rs > 0:
        index = 0
        records()

def nextRec():
    rs = query()
    global index
    # index = 0
    if tr > index:    # 2 > 3
        print(tr)
        print(rs)
        index += 1
        records()
    else:
        CTkMessagebox(title="Modify", message="Last Record", icon="info", icon_size=(30, 30), width=100, height=80)

def prevRec():
    rs = query()
    global index
    # index = rs
    if index > 0:
        print(tr)      # 2 2 2
        print(rs)      # 3 3 3
        index -= 1
        records()
    else:
        if rs == 0:
            records()
        else:
            CTkMessagebox(title="Modify", message="First Record", icon="info", icon_size=(30, 30), width=100, height=80)

def lastRec():
    print(tr)
    global index
    index = tr
    if tr > 0:
        records()

txtid = ctk.CTkEntry(app, placeholder_text="Enter ID to Search", width=300)
txtid.pack(pady=(40, 13))
ctk.CTkButton(app, text="Search", width=300, command=searchID).pack(pady=(0, 13))
txtfnm = ctk.CTkEntry(app, width=300)
txtfnm.pack(pady=(0, 13))
txtlnm = ctk.CTkEntry(app, width=300)
txtlnm.pack(pady=(0, 13))
txtemail = ctk.CTkEntry(app, width=300)
txtemail.pack(pady=(0, 13))
updateBtn = ctk.CTkButton(app, text="Update", width=300, command=updateRec)
updateBtn.pack(pady=(0, 13))
deleteBtn = ctk.CTkButton(app, text="Delete", width=300, command=deleteRec)
deleteBtn.pack(pady=(0, 13))
firstRecBtn = ctk.CTkButton(app, text="FIRST", width=70, command=firstRec)
firstRecBtn.place(x=49,y=326)
nextRecBtn = ctk.CTkButton(app, text="NEXT", width=70, command=nextRec)
nextRecBtn.place(x=125.5, y=326)
prevRecBtn = ctk.CTkButton(app, text="PREV", width=70, command=prevRec)
prevRecBtn.place(x=203, y=326)
lastRecBtn = ctk.CTkButton(app, text="LAST", width=70, command=lastRec)
lastRecBtn.place(x=279, y=326)

app.after(100, load)
app.mainloop()