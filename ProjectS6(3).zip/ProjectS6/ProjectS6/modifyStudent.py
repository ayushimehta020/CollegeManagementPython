from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry
import tkinter
import mysql.connector
from CTkMessagebox import CTkMessagebox
import datetime

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

gen = StringVar()
tr = 0
index = 0
course = StringVar()
year = StringVar()

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def searchID():
    global course
    global year
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None

    if id != None:
        sql = "SELECT * FROM student WHERE stud_id=%s"
        values = (id, )
        mycursor.execute(sql, values)
        res = mycursor.fetchall()

        clear()
        if len(res) > 0:
            for x in res:
                txtid.insert(0, x[0])
                txtnm.insert(0, x[1])
                # cmbcrs.set(x[2])
                course.set(x[2])
                year.set(x[3])
                cmbsem.set(x[4])
                lst = get_year()
                lst2 = get_sem(year.get())
                # print(lst2)
                cmbyear["values"] = lst 
                cmbyear.configure(values=lst)
                cmbsem["values"] = lst2
                cmbsem.configure(values=lst2)
                dtDob.set_date(x[5])
                txtmob.insert(0, x[6])
                txtage.insert(0, x[7])
                gender = x[8]
                gen1 = "Male" if gender == "M" else "Female"
                gen.set(gen1)
                Result.insert(1.0, x[9])
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="No record found!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter Valid ID!")

def get_courses():
    # course1 = course.get()
    sql = "SELECT name FROM course"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    lst = []
    # get_year()
    if len(res) > 0:
        for x in res:
            lst.append(x[0])
    return lst

def get_year():
    global course
    course1 = course.get()
    lst = []
    
    if course and course != "-- SELECT COURSE --":
        sql = "SELECT duration FROM course WHERE name=%s"
        values = (course1, )
        mycursor.execute(sql, values)
        res = mycursor.fetchall()
        print(res)
        if len(res) > 0:
            for i in range(1, int(res[0][0][0]) + 1):
                lst.append(str(i))
        cmbyear['values'] = lst
        cmbyear.configure(values=lst)
    return lst

def get_sem(year1, event=None):
    lst = []
    cmbsem.set("-- SELECT SEMESTER --") if event != None else lst
    if year1 == "1":
        lst.append("1")
        lst.append("2")
    elif year1 == "2":
        lst.append("3")
        lst.append("4")
    elif year1 == "3":
        lst.append("5")
        lst.append("6")
    elif year1 == "4":
        lst.append("7")
        lst.append("8")
    cmbsem["values"] = lst
    cmbsem.configure(values=lst)
    return lst

lst1 = get_courses()
# lst2 = []

def update():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None

    if id != None:
        name = txtnm.get()
        course1 = course.get()
        year1 = year.get()
        sem1 = cmbsem.get()
        dob = dtDob.get_date()
        mobile = txtmob.get()
        age = txtage.get()
        gender = gen.get()
        gen1 = "F" if gender == "Female" else "M"
        address = Result.get(1.0, END)

        if name.strip() and course1.strip() != "-- SELECT COURSE --" and year1.strip() != "-- SELECT YEAR --" and year1.strip() != "Please select course" and sem1.strip() != "-- SELECT SEMESTER --" and sem1.strip() != "Please select year" and dob and len(mobile.strip()) == 10 and mobile.strip().isnumeric() and age.strip() and int(age) >= 15 and gen1.strip() and address.strip():
            sql = "UPDATE student SET name=%s, course=%s, year=%s, semester=%s, dob=%s, mobile_no=%s, age=%s, gender=%s, address=%s WHERE stud_id=%s"
            values=(name, course1, year1, sem1, dob, mobile, age, gen1, address, id)
            mycursor.execute(sql, values)
            # res = mycursor.fetchall()
            db.commit()

            if mycursor.rowcount > 0:
                CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record updated successfully!")
            else:
                CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be  updated!")
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid values!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid ID!")

def delete():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None

    if id != None:
        sql = "DELETE FROM student WHERE stud_id=%s"
        values = (id,)
        mycursor.execute(sql, values)
        db.commit()

        if mycursor.rowcount > 0:
            CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record deleted successfully!")
            prev()
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be deleted!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid ID!")

def first():
    res = query()
    global index
    if res > 0:
        index = 0
        records()

def next():
    global index
    if tr > index:
        index += 1
        records()
    else:
        CTkMessagebox(frm, width=100, height=50, icon="info", icon_size=(20, 20), message="Last Record!")

def prev():
    res = query()
    global index

    if index > 0:
        index -= 1
        records()
    else:
        if res == 0:
            records()
        else:
            CTkMessagebox(frm, width=100, height=50, icon="info", icon_size=(20, 20), message="First Record!")

def last():
    global index
    index = tr
    if tr > 0:
        records()

def clear():
    txtid.delete(0, END)
    txtnm.delete(0, END)
    cmbcrs.set("-- SELECT COURSE --")
    cmbyear.set("-- SELECT YEAR --")
    cmbyear.configure(values=["Please select course"])
    cmbsem.set("-- SELECT SEMESTER --")
    cmbsem.configure(values=["Please select year"])
    dtDob.set_date(datetime.date.today())
    txtmob.delete(0, END)
    txtage.delete(0, END)
    gen.set("Male")
    Result.delete(1.0, END)

def load():
    global index
    index = 0
    records()

def records():
    global year
    global tr
    global index
    sql = "SELECT * FROM student"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    tr = len(res) - 1

    clear()
    if (len(res) > 0):
        txtid.insert(0, res[index][0])
        txtnm.insert(0, res[index][1])
        course.set(res[index][2])
        year.set(res[index][3])
        cmbsem.set(res[index][4])
        lst = get_year()
        lst2 = get_sem(year.get())
        cmbyear["values"] = lst
        cmbyear.configure(values=lst)
        cmbsem["values"] = lst2
        cmbsem.configure(values=lst2)
        dtDob.set_date(res[index][5])
        txtmob.insert(0, res[index][6])
        txtage.insert(0, res[index][7])
        gender = res[index][8]
        gen1 = "Male" if gender == "M" else "Female"
        gen.set(gen1)
        Result.insert(1.0, res[index][9])
    else:
        updateBtn._state = DISABLED
        deleteBtn._state = DISABLED
        firstBtn._state = DISABLED
        nextBtn._state = DISABLED
        prevBtn._state = DISABLED
        lastBtn._state = DISABLED

def query():
    sql = "SELECT * FROM student"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    return len(res)

imgtemp = CTkImage(light_image=Image.open("Images/mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

txtid = CTkEntry(frm, placeholder_text="Enter ID To Search")
txtid.grid(row=1, column=1, pady=(30, 5), padx=(30, 20), columnspan=4, sticky="we")

CTkButton(frm, text="Search", command=searchID).grid(row=2, column=1, padx=(30, 20), pady=(5, 10), columnspan=4, sticky="we")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=3, column=1, padx=(30, 5), pady=(10, 10), sticky="w", columnspan=2)
txtnm = CTkEntry(frm, width=260)
txtnm.grid(row=3, column=3, pady=(10, 10), padx=(0, 20), columnspan=2)

CTkLabel(frm, text="Select Course").grid(row=4, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
cmbcrs = CTkComboBox(frm, width=260, values=lst1, variable=course)
cmbcrs.set("-- SELECT COURSE --")
# cmbcrs.bind("<<ComboboxSelected>>", get_year)
cmbcrs.grid(row=4, column=3, padx=(0, 20), pady=(0, 10), columnspan=2)

CTkLabel(frm, text="Select Year").grid(row=5, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
year.set("1")
cmbyear = CTkComboBox(frm, width=260, variable=year, command=lambda event1="<<ComboboxSelected>>": get_sem(year1=year.get(), event=event1))
# cmbyear.set("-- SELECT YEAR --")
cmbyear.bind("<<ComboboxSelected>>", lambda e:get_sem(year1=year.get(), event=e))
cmbyear.grid(row=5, column=3, padx=(0, 20), pady=(0, 10), columnspan=2)

CTkLabel(frm, text="Select Semester").grid(row=6, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
cmbsem = CTkComboBox(frm, width=260)
# cmbsem.set("-- SELECT SEMESTER --")
cmbsem.grid(row=6, column=3, pady=(0, 10), padx=(0, 20), columnspan=2)

CTkLabel(frm, text="Date of Birth").grid(row=7, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
dt1 = datetime.date.today()
dt2 = datetime.date(dt1.year - 15, dt1.month, dt1.day)
dtDob = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=40, background="blue", foreground="white", fieldbackground="black", maxdate=dt2)
dtDob.grid(row=7, column=3, pady=(0, 10), padx=(0, 20), columnspan=2)

CTkLabel(frm, text="Enter Mobile Number").grid(row=8, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
txtmob = CTkEntry(frm, width=260)
txtmob.grid(row=8, column=3, pady=(0, 10), padx=(0, 20), columnspan=2)

# Age, Gender, Address
CTkLabel(frm, text="Enter Age").grid(row=9, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
txtage = CTkEntry(frm, width=260)
txtage.grid(row=9, column=3, pady=(0, 10), padx=(0, 20), columnspan=2)

CTkLabel(frm, text="Select Gender").grid(row=10, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
rbMale = CTkRadioButton(frm, text="Male", value="Male", radiobutton_height=14, radiobutton_width=14, border_width_checked=3, variable=gen, border_width_unchecked=2)
rbMale.grid(row=10, column=3, pady=(0, 10))

rbFemale = CTkRadioButton(frm, text="Female", value="Female", radiobutton_height=14, border_width_checked=3, radiobutton_width=14, variable=gen, border_width_unchecked=2)
rbFemale.grid(row=10, column=4, pady=(0, 10))

CTkLabel(frm, text="Enter Address").grid(row=11, column=1, padx=(30, 5), pady=(0, 10), sticky="w", columnspan=2)
# txtAddr = CTkTextbox(frm, height=10)
# txtAddr.grid(row=8, column=2, pady=(0, 10), sticky="nsew")
# scrollBar = CTkScrollbar(frm, command=txtAddr.yview)
# scrollBar.grid(row=8, column=3, sticky="ns")
# txtAddr.configure(yscrollcommand=scrollBar.set)

# scrollBar = tkinter.Scrollbar(frm, orient="vertical")
# scrollBar.grid(row=8, column=2)
# txtAddr = tkinter.Text(frm, yscrollcommand=scrollBar.set, height=5, width=20)
# scrollBar.config(command=txtAddr.yview)
# txtAddr.grid(row=8, column=1)

# txt = tkinter.Text(frm, width=20, height=8)
# txt.grid(row=8, column=2, sticky="nsew", pady=(0, 30))

# create a Scrollbar and associate it with txt
# scrollb = tkinter.Scrollbar(frm, command=txt.yview, height=50)
# scrollb.grid(row=8, column=2, padx=(240, 0))
# txt['yscrollcommand'] = scrollb.set

# Result = tkinter.Text(frm,height=3,width=27)
# Result.place(x=208, y=340)
 
# Scroll = tkinter.Scrollbar(frm,command=Result.yview)
# Scroll.grid(row=9,column=3,padx=12,sticky='NS')
# Result.config(yscrollcommand=Scroll.set)

text_frame = CTkFrame(frm, width=220, height=100, fg_color="transparent")
text_frame.grid(row=11, column=3, pady=(0, 20), sticky="nsew", padx=(0, 10), columnspan=2)

# Add the Text widget
Result = tkinter.Text(text_frame, height=5, width=0, wrap="word", bd=0, relief="flat")
Result.pack(side="left", fill="both", expand=True)
# Result.place(x=0,y=0, anchor="nw", relwidth=0.5, relheight=1.0, padx=(0, 10))

# Add the scrollbar inside the same frame
Scroll = tkinter.Scrollbar(text_frame, command=Result.yview)
Scroll.pack(side="right", fill="y", padx=(0, 15))
Result.config(yscrollcommand=Scroll.set)  # Linking Text widget with Scrollbar

updateBtn = CTkButton(frm, text="Update", width=245, fg_color="#d68d02", hover_color="#a16a02", command=update)
updateBtn.grid(row=12, column=1, padx=(26, 0), pady=(30, 10), columnspan=2)
deleteBtn = CTkButton(frm, text="Delete", width=245, fg_color="red", hover_color="#a30202", command=delete)
deleteBtn.grid(row=12, column=3, padx=3, pady=(30, 10), columnspan=2)

firstBtn = CTkButton(frm, text="FIRST", width=110, command=first)
firstBtn.grid(row=13, column=1, padx=(30, 10), pady=(5, 20))
nextBtn = CTkButton(frm, text="NEXT", width=110, command=next)
nextBtn.grid(row=13, column=2, padx=(13, 10), pady=(5, 20))
prevBtn = CTkButton(frm, text="PREV", width=110, command=prev)
prevBtn.grid(row=13, column=3, padx=(0, 0), pady=(5, 20))
lastBtn = CTkButton(frm, text="LAST", width=110, command=last)
lastBtn.grid(row=13, column=4, padx=(0, 6), pady=(5, 20))

app.after(100, load)
app.mainloop()