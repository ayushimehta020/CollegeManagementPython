from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry
import datetime
import mysql.connector
from CTkMessagebox import CTkMessagebox

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state("zoomed"))
app.title("College")

# attendance = StringVar()
attendance_data = {}

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()
course = StringVar()

y_position = 0

def load_stud():
    global y_position
    global attendance
    global attendance_data

    if course.get() != "-- SELECT COURSE --":
        y_position = 190

        dtSelected = date.get_date()
        attendance_data.clear()

        for widget in frm.winfo_children():
            if isinstance(widget, CTkLabel) or isinstance(widget, CTkRadioButton) or isinstance(widget, CTkButton):
                widget.destroy()
        
        CTkLabel(frm, text="Please select course").place(x=20, rely=0.05)
        CTkLabel(frm, text="Mark all").place(x=20, rely=0.22)
        cmbMarkAll.place(x=170, rely=0.22)

        sql = "SELECT stud_id, name FROM student WHERE course=%s"
        values = (course.get(), )
        mycursor.execute(sql, values)
        res = mycursor.fetchall()

        # y_position=100

        for student_id, student_name in res:
            sql = "SELECT status FROM stud_attendance WHERE student_id=%s AND date=%s"
            values = (student_id, dtSelected)
            mycursor.execute(sql, values)
            att_rec = mycursor.fetchone()

            att_status = att_rec[0] if att_rec else "Present"
            
            CTkLabel(frm, text=student_name).place(x=20, y=y_position)

            attendance = StringVar(value=att_status)
            attendance_data[student_id] = attendance

            CTkRadioButton(frm, value="Present", text="Present", variable=attendance, radiobutton_height=14, radiobutton_width=14, border_width_checked=3, border_width_unchecked=2).place(x=170, y=y_position)
            CTkRadioButton(frm, value="Absent", text="Absent", variable=attendance, radiobutton_height=14, radiobutton_width=14, border_width_checked=3, border_width_unchecked=2).place(x=270, y=y_position)
            CTkRadioButton(frm, value="Leave", text="Leave", variable=attendance, radiobutton_height=14, radiobutton_width=14, border_width_checked=3, border_width_unchecked=2).place(x=370, y=y_position)

            y_position += 40
    else:
        return
    
    CTkButton(frm, text="Mark Attendance", command=mark_attendance, width=200).place(x=20, y=y_position)
    CTkButton(frm, text="Update Attendance", command=update_attendance, width=200).place(x=240, y=y_position)

def mark_attendance():
    dtSelected = date.get_date()
    count1 = 0

    for student_id, var in attendance_data.items():
        sql = "SELECT COUNT(*) FROM stud_attendance WHERE student_id=%s AND date=%s"
        values = (student_id, dtSelected)
        mycursor.execute(sql, values)
        count = mycursor.fetchone()[0]

        if count == 0:
            sql = "INSERT INTO stud_attendance(student_id, date, status) VALUES(%s, %s, %s)"
            values = (student_id, dtSelected, var.get())
            mycursor.execute(sql, values)
            db.commit()
            count1 += mycursor.rowcount

    if count1 > 0:
        CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Attendance taken successfully!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Attendance already taken for all students!")
            # attendance.set("Present")

def update_attendance():
    dtSelected = date.get_date()

    sql = "SELECT COUNT(*) FROM stud_attendance WHERE date=%s"
    values = (dtSelected,)
    mycursor.execute(sql, values)
    count = mycursor.fetchone()[0]

    if count == 0:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="No attendance taken for this date!")
        return
    
    for student_id, var in attendance_data.items():
        sql = "UPDATE stud_attendance SET status=%s WHERE student_id=%s AND date=%s"
        values = (var.get(), student_id, dtSelected)
        mycursor.execute(sql, values)
        db.commit()
        count1 = mycursor.rowcount
    
    if count1 > 0:
        CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Attendance updated successfully!")

def on_date_change(event):
    cmb_sel()

def mark_all(event):
    selected_val = cmbMarkAll.get()
    
    for student_id, var in attendance_data.items():
        if selected_val == "Absent":
            var.set("Absent")
        elif selected_val == "Leave":
            var.set("Leave")
        elif selected_val == "Present":
            var.set("Present")
    cmbMarkAll.set("-- SELECT --")

def all_courses():
    lst = []
    sql = "SELECT name FROM course"
    mycursor.execute(sql)
    res = mycursor.fetchall()

    for x in res:
        lst.append(x[0])
    
    return lst

lst1 = all_courses()

def cmb_sel(event=None):
    global course
    if (course.get() != "-- SELECT COURSE --"):
        load_stud()
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Please select course!")

imgtemp = CTkImage(light_image=Image.open("Images/mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=460, height=500, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

CTkLabel(frm, text="Please select course").place(x=20, rely=0.05)
cmbCourse = CTkComboBox(frm, width=270, values=lst1, command=cmb_sel, variable=course)
cmbCourse.set("-- SELECT COURSE --")
cmbCourse.place(x=170, rely=0.05)

date = DateEntry(frm, date_pattern="yyyy/mm/dd", cursor="hand2", maxdate=datetime.date.today(), COMMAND=on_date_change)
date.bind("<<DateEntrySelected>>", on_date_change)
date.place(x=20, rely=0.14, width=frm.winfo_width() - 40)

CTkLabel(frm, text="Mark all").place(x=20, rely=0.22)
cmbMarkAll = CTkComboBox(frm, width=270, values=["Present", "Absent", "Leave"], command=mark_all)
cmbMarkAll.set("-- SELECT --")
cmbMarkAll.place(x=170, rely=0.22)

# load_stud()

# print(y_position)
# print(attendance_data)
# CTkButton(frm, text="Mark Attendance", command=mark_attendance, width=200).place(x=20, y=y_position + 20)
# CTkButton(frm, text="Update Attendance", command=update_attendance, width=200).place(x=240, y=y_position + 20)

app.mainloop()