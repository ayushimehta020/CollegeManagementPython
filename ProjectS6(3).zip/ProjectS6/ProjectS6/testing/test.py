import requests
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox

url = "http://ayushi.dvl.to/bscitapi.php"

def search():
    action = "Select"
    id = txtid.get()
    if id.strip():
        data = {"id":id, "action":action}
        resp = requests.post(url, data)
        ary = resp.json()
        clear()
        if (ary['data'] != '0'):
            txtenr.insert(0, ary['data'])
            txtnm.insert(0, ary['name'])
            txteml.insert(0, ary['email'])
            txtpwd.insert(0, ary['pwd'])
            txtmob.insert(0, ary['mob_no'])
            txtcourse.insert(0, ary['course'])
        else:
            CTkMessagebox(app, message="Enter Valid ID!", title="Python API", width=700, height=500, icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
    else:
        CTkMessagebox(app, message="Enter ID!", title="Python API", width=700, height=500, icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
        txtid.delete(0, ctk.END)
        txtid.configure(placeholder_text="Enter ID to Search")
        clear()

def insert():
    action = "Insert"
    enr = txtenr.get()
    name = txtnm.get()
    email = txteml.get()
    password = txtpwd.get()
    mob = txtmob.get()
    course = txtcourse.get()
    if enr.strip() and name.strip() and email.strip() and password.strip() and len(mob.strip()) == 10 and course.strip():
        data = {"enr":enr, "name":name, "email":email, "pwd":password, "mob":mob, "course":course, "action":action}
        resp = requests.post(url, data)
        ary = resp.json()
        if ary['data'] != '0':
            CTkMessagebox(app, width=700, height=500, title="Python API", message="Record Inserted Successfully!", icon="check", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
        else:
            CTkMessagebox(app, width=700, height=500, title="Python API", message="Record Cannot Be Inserted!", icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
    else:
        CTkMessagebox(app, width=700, height=500, title="Python API", message="Enter Valid Values!", icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
        txtid.delete(0, ctk.END)
        txtid.configure(placeholder_text="Enter ID to Search")
        clear()

def update():
    action = "Update"
    id = txtid.get()
    enr = txtenr.get()
    name = txtnm.get()
    email = txteml.get()
    password = txtpwd.get()
    mob = txtmob.get()
    course = txtcourse.get()
    if id.strip() and enr.strip() and name.strip() and email.strip() and password.strip() and len(mob.strip()) == 10 and course.strip():
        data = {"action":action, "id":id, "enr":enr, "name":name, "email":email, "pwd":password, "mob":mob, "course":course}
        resp = requests.post(url, data)
        ary = resp.json()
        if ary['data'] != '0':
            CTkMessagebox(app, width=700, height=500, title="Python API", message="Record Updated Successfully!", icon="check", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
        else:
            CTkMessagebox(app, width=700, height=500, title="Python API", message="Record Cannot Be Updated!", icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
    else:
        CTkMessagebox(app, width=700, height=500, title="Python API", message="Enter Valid Values!", icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
        txtid.delete(0, ctk.END)
        txtid.configure(placeholder_text="Enter ID to Search")
        clear()

def delete():
    action = "Delete"
    id = txtid.get()
    if id.strip():
        data = {"action":action, "id":id}
        resp = requests.post(url, data)
        ary = resp.json()
        if ary['data'] != '0':
            CTkMessagebox(app, width=700, height=500, title="Python API", message="Record Deleted Successfully!", icon="check", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
        else:
            CTkMessagebox(app, width=700, height=500, title="Python API", message="Record Cannot Be Deleted!", icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
            txtid.delete(0, ctk.END)
            txtid.configure(placeholder_text="Enter ID to Search")
            clear()
    else:
        CTkMessagebox(app, width=700, height=500, title="Python API", message="Enter ID!", icon="cancel", icon_size=(70, 70), font=("Ubuntu", 25))
        txtid.delete(0, ctk.END)
        txtid.configure(placeholder_text="Enter ID to Search")
        clear()

def clear():
    txtenr.delete(0, ctk.END)
    txtenr.configure(placeholder_text="Enter Enrollment Number")
    txtnm.delete(0, ctk.END)
    txtnm.configure(placeholder_text="Enter Name")
    txteml.delete(0, ctk.END)
    txteml.configure(placeholder_text="Enter Email")
    txtpwd.delete(0, ctk.END)
    txtpwd.configure(placeholder_text="Enter Password")
    txtmob.delete(0, ctk.END)
    txtmob.configure(placeholder_text="Enter Mobile Number")
    txtcourse.delete(0, ctk.END)
    txtcourse.configure(placeholder_text="Enter Course")

app = ctk.CTk()
app.geometry("1400x1700")

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

txtid = ctk.CTkEntry(app, placeholder_text="Enter ID to Search", font=("Ubuntu", 25))
txtid.pack(fill="x", padx=30, pady=(130, 15))
ctk.CTkButton(app, text="Search", font=("Ubuntu", 25), height=80, command=search).pack(fill="x", padx=30, pady=20)
txtenr = ctk.CTkEntry(app, font=("Ubuntu", 25), height=80, placeholder_text="Enter Enrollment Number")
txtenr.pack(fill="x", padx=30, pady=20)
txtnm = ctk.CTkEntry(app, font=("Ubuntu", 25), height=80, placeholder_text="Enter Name")
txtnm.pack(fill="x", padx=30, pady=20)
txteml = ctk.CTkEntry(app, font=("Ubuntu", 25), height=80, placeholder_text="Enter Email")
txteml.pack(fill="x", padx=30, pady=20)
txtpwd = ctk.CTkEntry(app, font=("Ubuntu", 25), height=80, placeholder_text="Enter Password", show="*")
txtpwd.pack(fill="x", padx=30, pady=20)
txtmob = ctk.CTkEntry(app, font=("Ubuntu", 25), height=80, placeholder_text="Enter Mobile Number")
txtmob.pack(fill="x", padx=30, pady=20)
txtcourse = ctk.CTkEntry(app, font=("Ubuntu", 25), height=80, placeholder_text="Enter Course")
txtcourse.pack(fill="x", padx=30, pady=20)
ctk.CTkButton(app, text="Insert", font=("Ubuntu", 25), height=80, command=insert).pack(fill="x", padx=30, pady=20)
ctk.CTkButton(app, text="Update", font=("Ubuntu", 25), height=80, command=update).pack(fill="x", padx=30, pady=20)
ctk.CTkButton(app, text="Delete", font=("Ubuntu", 25), height=80, command=delete).pack(fill="x", padx=30, pady=20)
ctk.CTkButton(app, text="Clear", font=("Ubuntu", 25), height=80, command=clear).pack(fill="x", padx=30, pady=20)

app.mainloop()