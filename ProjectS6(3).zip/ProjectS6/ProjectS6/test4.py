from tkinter import *
# import tkMessageBox
  
top = Tk()
top.wm_title("Checklist")
my_items = ['Underwear', 'T_shirst', 'Socks', 'Hats'] # you can expand list of items/check-boxes
check_boxes = {item:IntVar() for item in my_items} #create dict of check_boxes
 
def confirm():
    print(all(item.get() for item in check_boxes.values())) # just for info to show you the reasult
    if all(item.get() for item in check_boxes.values()):
        pass # do something you want
 
#create all check-boxes on the form
for item in my_items:
    C = Checkbutton(top, text = item, variable = check_boxes[item], anchor = W,  onvalue = 1, offvalue = 0, height=1, width = 40)
    C.pack()
 
B1 = Button(top, text = "Sprawdz", command = confirm)
B1.pack()
 
  
top.mainloop()