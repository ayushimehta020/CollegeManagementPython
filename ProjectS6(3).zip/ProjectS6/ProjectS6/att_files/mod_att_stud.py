from customtkinter import *
from PIL import Image
import mysql.connector
from CTkMessagebox import CTkMessagebox
from tkcalendar import DateEntry

app = CTk()
app.attributes("-zoomed", True)
app.title("Modify Student Attendance")

# Database connection
db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def load_attendance():
    selected_date = date_entry.get_date()
    for widget in frame.winfo_children():
        widget.destroy()

    sql = "SELECT student_id, status FROM attendance WHERE date = %s"
    mycursor.execute(sql, (selected_date,))
    records = mycursor.fetchall()

    attendance_vars = {}
    for index, (student_id, status) in enumerate(records):
        sql = "SELECT name FROM students WHERE id = %s"
        mycursor.execute(sql, (student_id,))
        name = mycursor.fetchone()[0]

        attendance_vars[student_id] = StringVar(value=status)
        CTkLabel(frame, text=name).grid(row=index + 1, column=0, padx=10, pady=5)
        CTkRadioButton(frame, text="Present", variable=attendance_vars[student_id], value="Present").grid(row=index + 1, column=1)
        CTkRadioButton(frame, text="Absent", variable=attendance_vars[student_id], value="Absent").grid(row=index + 1, column=2)
        CTkRadioButton(frame, text="Leave", variable=attendance_vars[student_id], value="Leave").grid(row=index + 1, column=3)

    CTkButton(frame, text="Update Attendance", command=lambda: update_attendance(attendance_vars, selected_date)).grid(row=len(records) + 1, column=0, columnspan=4, pady=10)

def update_attendance(attendance_vars, selected_date):
    for student_id, status_var in attendance_vars.items():
        sql = "UPDATE attendance SET status = %s WHERE student_id = %s AND date = %s"
        mycursor.execute(sql, (status_var.get(), student_id, selected_date))
    
    db.commit()
    CTkMessagebox(app, message="Attendance updated successfully!")

frame = CTkFrame(app)
frame.pack(pady=20)

date_label = CTkLabel(frame, text="Select Date:")
date_label.grid(row=0, column=0, padx=10, pady=10)

date_entry = DateEntry(frame, date_pattern="yyyy-mm-dd")
date_entry.grid(row=0, column=1, padx=10, pady=10)

CTkButton(frame, text="Load Attendance", command=load_attendance).grid(row=0, column=2, padx=10, pady=10)

app.mainloop()
