from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry
import datetime
import mysql.connector
from CTkMessagebox import CTkMessagebox

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state("zoomed"))
# app.attributes("-zoomed", True)
app.title("College")

# attendance = StringVar()
attendance_data = {}

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

y_position = 0

def load_stud():
    global y_position
    global attendance
    global attendance_data

    y_position = 200

    dtSelected = date.get_date()
    print(date)
    attendance_data.clear()

    for widget in frm.winfo_children():
        if isinstance(widget, CTkLabel) or isinstance(widget, CTkRadioButton):
            widget.destroy()
    
    CTkLabel(frm, text="Mark all").place(x=20, rely=0.3)
    cmbMarkAll.place(x=260, rely=0.3)

    sql = "SELECT faculty_id, name FROM faculty"
    mycursor.execute(sql)
    res = mycursor.fetchall()

    # y_position=100

    for faculty_id, faculty_name in res:
        sql = "SELECT status FROM fac_attendance WHERE faculty_id=%s AND date=%s"
        values = (faculty_id, dtSelected)
        mycursor.execute(sql, values)
        att_rec = mycursor.fetchone()

        att_status = att_rec[0] if att_rec else "Present"
        
        CTkLabel(frm, text=faculty_name).place(x=20, y=y_position)

        attendance = StringVar(value=att_status)
        attendance_data[faculty_id] = attendance

        CTkRadioButton(frm, value="Present", variable=attendance).place(x=150, y=y_position)
        CTkRadioButton(frm, value="Absent", variable=attendance).place(x=250, y=y_position)
        CTkRadioButton(frm, value="Leave", variable=attendance).place(x=350, y=y_position)

        y_position += 40

def mark_attendance():
    dtSelected = date.get_date()
    count1 = 0  # Counter to track new attendance entries

    for faculty_id, var in attendance_data.items():
        # Check if attendance exists for this student on the selected date
        sql = "SELECT COUNT(*) FROM fac_attendance WHERE faculty_id=%s AND date=%s"
        values = (faculty_id, dtSelected)
        mycursor.execute(sql, values)
        count = mycursor.fetchone()[0]

        if count == 0:  # If attendance is NOT taken, insert it
            sql = "INSERT INTO fac_attendance(faculty_id, date, status) VALUES(%s, %s, %s)"
            values = (faculty_id, dtSelected, var.get())
            mycursor.execute(sql, values)
            db.commit()
            count1 += mycursor.rowcount  # Track successful inserts

    # Show appropriate message
    if count1 > 0:
        CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Attendance taken successfully!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Attendance already taken for all faculties!")
            # attendance.set("Present")

def update_attendance():
    dtSelected = date.get()

    sql = "SELECT COUNT(*) FROM fac_attendance WHERE date=%s"
    values = (dtSelected,)
    mycursor.execute(sql, values)
    count = mycursor.fetchone()[0]

    if count == 0:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="No attendance taken for this date!")
        return
    
    for faculty_id, var in attendance_data.items():
        sql = "UPDATE fac_attendance SET status=%s WHERE faculty_id=%s AND date=%s"
        values = (var.get(), faculty_id, dtSelected)
        mycursor.execute(sql, values)
        db.commit()
        count1 = mycursor.rowcount
    
    if count1 > 0:
        CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Attendance updated successfully!")


def on_date_change(event):
    load_stud()

def mark_all(event):
    selected_val = cmbMarkAll.get()
    
    for faculty_id, var in attendance_data.items():
        if selected_val == "Absent":
            var.set("Absent")
        elif selected_val == "Leave":
            var.set("Leave")
        elif selected_val == "Present":
            var.set("Present")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

date = DateEntry(frm, date_pattern="yyyy/mm/dd", cursor="hand2", maxdate=datetime.date.today(), COMMAND=on_date_change)
date.bind("<<DateEntrySelected>>", on_date_change)
date.place(x=20, rely=0.1, width=frm.winfo_width() - 40)

CTkLabel(frm, text="Mark all").place(x=20, rely=0.3)
cmbMarkAll = CTkComboBox(frm, width=220, values=["Present", "Absent", "Leave"], command=mark_all)
cmbMarkAll.set("-- SELECT --")
cmbMarkAll.place(x=260, rely=0.3)

load_stud()

# print(y_position)
print(attendance_data)
CTkButton(frm, text="Mark Attendance", command=mark_attendance).place(x=20, y=y_position + 20)
CTkButton(frm, text="Update Attendance", command=update_attendance).place(x=120, y=y_position + 20)

app.mainloop()