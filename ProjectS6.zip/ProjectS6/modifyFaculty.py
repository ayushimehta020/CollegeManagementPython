from customtkinter import *
from PIL import Image
from tkcalendar import DateEntry

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

gen = StringVar()

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

txtid = CTkEntry(frm, placeholder_text="Enter ID To Search")
txtid.grid(row=1, column=1, pady=(15, 5), padx=(30, 20), columnspan=4, sticky="we")

CTkButton(frm, text="Search").grid(row=2, column=1, padx=(30, 20), pady=(5, 0), columnspan=4, sticky="we")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=3, column=1, padx=(30, 12), pady=(10, 10), sticky="w", columnspan=2)
txtnm = CTkEntry(frm, width=220)
txtnm.grid(row=3, column=3, pady=(10, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Date of Birth").grid(row=4, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
dtDob = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=33, background="blue", foreground="white", fieldbackground="black")
dtDob.grid(row=4, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Age").grid(row=5, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtage = CTkEntry(frm, width=220)
txtage.grid(row=5, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Gender").grid(row=6, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
rbMale = CTkRadioButton(frm, text="Male", value="Male", radiobutton_height=14, radiobutton_width=14, border_width_checked=3, variable=gen, border_width_unchecked=2)
rbMale.grid(row=6, column=3, pady=(0, 10))

rbFemale = CTkRadioButton(frm, text="Female", value="Female", radiobutton_height=14, border_width_checked=3, radiobutton_width=14, variable=gen, border_width_unchecked=2)
rbFemale.grid(row=6, column=4, pady=(0, 10))

CTkLabel(frm, text="Enter Email").grid(row=7, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtemail = CTkEntry(frm, width=220)
txtemail.grid(row=7, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Mobile Number").grid(row=8, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtmob = CTkEntry(frm, width=220)
txtmob.grid(row=8, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Experience").grid(row=9, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtexp = CTkEntry(frm, width=220)
txtexp.grid(row=9, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Experience").grid(row=10, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtexp = CTkEntry(frm, width=220)
txtexp.grid(row=10, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Department").grid(row=11, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
chkVal1 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="IT")
chkVal1.grid(row=11, column=3, pady=(0, 10), padx=(10, 20))
chkVal2 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Commerce")
chkVal2.grid(row=11, column=4, pady=(0, 10), padx=(10, 20))
chkVal3 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Management")
chkVal3.grid(row=12, column=3, pady=(0, 10), padx=(10, 20))
chkVal4 = CTkCheckBox(frm, checkbox_width=20, checkbox_height=20, text="Other")
chkVal4.grid(row=12, column=4, pady=(0, 10), padx=(10, 20))

CTkLabel(frm, text="Enter Salary").grid(row=15, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtsal = CTkEntry(frm, width=220)
txtsal.grid(row=15, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Joining Date").grid(row=16, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
dtJoin = DateEntry(frm, date_pattern="yyyy-mm-dd", cursor="hand2", width=33, background="blue", foreground="white", fieldbackground="black")
dtJoin.grid(row=16, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Qualification").grid(row=17, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtqual = CTkEntry(frm, width=220)
txtqual.grid(row=17, column=3, pady=(0, 20), padx=(10, 20), columnspan=2)

CTkButton(frm, text="Update", width=210, fg_color="#d68d02", hover_color="#a16a02").grid(row=18, column=1, padx=(30, 6), pady=(15, 5), columnspan=2)
CTkButton(frm, text="Delete", width=210, fg_color="red", hover_color="#a30202").grid(row=18, column=3, padx=6, pady=(15, 5), columnspan=2)

CTkButton(frm, text="FIRST", width=100).grid(row=19, column=1, padx=(30, 10), pady=(5, 10))
CTkButton(frm, text="NEXT", width=100).grid(row=19, column=2, padx=(13, 10), pady=(5, 10))
CTkButton(frm, text="PREV", width=100).grid(row=19, column=3, padx=(5, 0), pady=(5, 10))
CTkButton(frm, text="LAST", width=100).grid(row=19, column=4, padx=(0, 6), pady=(5, 10))

app.mainloop()