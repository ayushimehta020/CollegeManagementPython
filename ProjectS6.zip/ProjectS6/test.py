from tkinter import *
from tkinter import ttk

init_list = ['Mickey', 'Minnie', 'Donald', 'Pluto', 'Goofy']

def db_values():
    i = inp_var.get()
    db_list = [x for x in init_list if i in x]
    print(db_list)
    return db_list

def db_refresh(event):
    db['values'] = db_values()

root = Tk()
title_label = Label(root, text="Partial string example")
title_label.grid(column=0, row=0)

inp_var = StringVar()
input_box = Entry(root, textvariable=inp_var)
input_box.grid(column=0, row=1)

name_selected = StringVar()
db = ttk.Combobox(root, textvariable=name_selected)
db['values'] = db_values()
db.bind('<FocusIn>', lambda event: db_refresh(event))
db.grid(column=0, row=2, sticky=EW, columnspan=3, padx=5, pady=2)

root.mainloop()