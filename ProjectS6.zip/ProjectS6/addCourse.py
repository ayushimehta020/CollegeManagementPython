from customtkinter import *
from PIL import Image

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=1, column=1, padx=(30, 12), pady=(30, 10), sticky="w")
txtnm = CTkEntry(frm, width=150)
txtnm.grid(row=1, column=2, pady=(30, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Fees").grid(row=2, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtmob = CTkEntry(frm, width=150)
txtmob.grid(row=2, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Duration").grid(row=3, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
cmbcrs = CTkComboBox(frm, width=150)
cmbcrs.grid(row=3, column=2, padx=(10, 20), pady=(0, 10), columnspan=2)

CTkButton(frm, text="Insert", width=140).grid(row=10, column=1, padx=(30, 6), pady=(30, 20))
CTkButton(frm, text="Clear", width=140, fg_color="red", hover_color="#a30202").grid(row=10, column=2, padx=6, pady=(30, 20), columnspan=2)

app.mainloop()