from customtkinter import *
from PIL import Image

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

txtid = CTkEntry(frm, placeholder_text="Enter ID To Search")
txtid.grid(row=1, column=1, pady=(30, 5), padx=(30, 20), columnspan=4, sticky="we")

CTkButton(frm, text="Search").grid(row=2, column=1, padx=(30, 20), pady=(5, 10), columnspan=4, sticky="we")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=3, column=1, padx=(30, 12), pady=(10, 10), sticky="w", columnspan=2)
txtnm = CTkEntry(frm, width=150)
txtnm.grid(row=3, column=3, pady=(10, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Fees").grid(row=4, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtmob = CTkEntry(frm, width=150)
txtmob.grid(row=4, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Duration").grid(row=5, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
cmbcrs = CTkComboBox(frm, width=150)
cmbcrs.grid(row=5, column=3, padx=(10, 20), pady=(0, 10), columnspan=2)

CTkButton(frm, text="Update", width=140, fg_color="#d68d02", hover_color="#a16a02").grid(row=6, column=1, padx=(30, 6), pady=(30, 10), columnspan=2)
CTkButton(frm, text="Delete", width=140, fg_color="red", hover_color="#a30202").grid(row=6, column=3, padx=6, pady=(30, 10), columnspan=2)

CTkButton(frm, text="FIRST", width=60).grid(row=7, column=1, padx=(30, 10), pady=(5, 20))
CTkButton(frm, text="NEXT", width=60).grid(row=7, column=2, padx=(13, 10), pady=(5, 20))
CTkButton(frm, text="PREV", width=60).grid(row=7, column=3, padx=(5, 0), pady=(5, 20))
CTkButton(frm, text="LAST", width=60).grid(row=7, column=4, padx=(0, 6), pady=(5, 20))

app.mainloop()