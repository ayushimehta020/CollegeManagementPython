'''
TRUNCATE TABLE course;
INSERT INTO course (name, fees, duration)
VALUES
    ('BSCIT', 26000, '3 YEARS'),
    ('BCA', 26000, '3 YEARS'),
    ('BCOM', 20000, '3 YEARS'),
    ('BED', 20000, '4 YEARS'),
    ('PGDCA', 15000, '1 YEAR');
'''

from customtkinter import *
from PIL import Image
import mysql.connector
from CTkMessagebox import CTkMessagebox

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

tr = 0
index = 0

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def searchID():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None
    # id = txtid.get()
    if id != None:
        sql = "SELECT * FROM course WHERE course_id=%s"
        values = (id, )
        mycursor.execute(sql, values)
        res = mycursor.fetchall()

        txtnm.delete(0, END)
        txtfees.delete(0, END)
        cmbdur.set("-- SELECT DURATION --")
        if (len(res)) > 0:
            for x in res:
                txtnm.insert(0, x[1])
                txtfees.insert(0, x[2])
                cmbdur.set(x[3])
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="No record found!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter valid ID!")

def load():
    global index
    index = 0
    records()

def update():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None
    name = txtnm.get()
    fees = txtfees.get()
    dur = cmbdur.get()
    if id != None and name.strip() and fees.strip() and dur != "-- SELECT DURATION --":
        sql = "UPDATE course SET name=%s, fees=%s, duration=%s WHERE course_id=%s"
        values = (name, fees, dur, id)
        mycursor.execute(sql, values)
        db.commit()

        if mycursor.rowcount > 0:
            CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record updated successfully!")
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be updated!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter ID!")

def delete():
    idStr = txtid.get()
    id = int(idStr) if idStr.isdecimal() else None

    if id != None:
        sql = "SELECT * FROM course"
        mycursor.execute(sql)
        res = mycursor.fetchall()
        res1 = res[0][0]

        sql = "DELETE FROM course WHERE course_id=%s"
        values = (id, )
        mycursor.execute(sql, values)
        db.commit()

        if mycursor.rowcount > 0:
            CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record deleted successfully!")

            # id = res[0][0]
            # print(id)              # 2
            # print(res[0][0])       # 1
            # print(id == res[0][0]) # False

            # if id == res1:
            #     next()
            # else:
            #     prev()

            prev()
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record cannot be deleted!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter ID!")

def first():
    res = query()
    global index
    if res > 0:
        index = 0
        records()

def next():
    global index
    print(tr) # 2
    if tr > index: # 2 > 1
        index += 1
        records()
    else:
        CTkMessagebox(frm, width=100, height=50, icon="info", icon_size=(20, 20), message="Last Record!")

# def prev():
#     res = query()
#     global index
#     # index = tr
#     if index > 0:
#         index -= 1
#         records()
#     else:
#         if res == 0:
#             records()
#         else:
#             CTkMessagebox(frm, width=100, height=50, icon="info", icon_size=(20, 20), message="First record!")

def prev():
    rs = query()
    global index
    print(index) # 1
    # index = rs
    if index > 0:
        # print(tr) # 1     # 2 2 2
        print(rs) # 1     # 3 3 3
        index -= 1
        records()
    else:
        if rs == 0:
            records()
        else:
            CTkMessagebox(title="Modify", message="First Record", icon="info", icon_size=(30, 30), width=100, height=80)

def last():
    global index
    index = tr
    if tr > 0:
        records()

def records():
    sql = "SELECT * FROM course"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    print(len(res)) # 1
    global tr
    tr = len(res) - 1 # 2
    global index # 3
    print(index) # 0

    clear()
    if len(res) > 0: # 3 > 0
        txtid.insert(0, res[index][0])
        txtnm.insert(0, res[index][1])
        txtfees.insert(0, res[index][2])
        cmbdur.set(res[index][3])
    else:
        updateBtn._state = DISABLED
        deleteBtn._state = DISABLED
        firstRecBtn._state = DISABLED
        nextRecBtn._state = DISABLED
        prevRecBtn._state = DISABLED
        lastRecBtn._state = DISABLED

def query():
    sql = "SELECT * FROM course"
    mycursor.execute(sql)
    res = mycursor.fetchall()
    return len(res)

def clear():
    txtid.delete(0, END)
    txtnm.delete(0, END)
    txtfees.delete(0, END)
    cmbdur.set("-- SELECT DURATION --")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

txtid = CTkEntry(frm, placeholder_text="Enter ID To Search")
txtid.grid(row=1, column=1, pady=(30, 5), padx=(30, 20), columnspan=4, sticky="we")

CTkButton(frm, text="Search", command=searchID).grid(row=2, column=1, padx=(30, 20), pady=(5, 10), columnspan=4, sticky="we")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=3, column=1, padx=(30, 12), pady=(10, 10), sticky="w", columnspan=2)
txtnm = CTkEntry(frm, width=150)
txtnm.grid(row=3, column=3, pady=(10, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Fees").grid(row=4, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
txtfees = CTkEntry(frm, width=150)
txtfees.grid(row=4, column=3, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Duration").grid(row=5, column=1, padx=(30, 12), pady=(0, 10), sticky="w", columnspan=2)
cmbdur = CTkComboBox(frm, width=150, values=("1 YEAR", "2 YEARS", "3 YEARS", "4 YEARS"))
cmbdur.set("-- SELECT DURATION --")
cmbdur.grid(row=5, column=3, padx=(10, 20), pady=(0, 10), columnspan=2)

updateBtn = CTkButton(frm, text="Update", width=140, fg_color="#d68d02", hover_color="#a16a02", command=update)
updateBtn.grid(row=6, column=1, padx=(30, 6), pady=(30, 10), columnspan=2)
deleteBtn = CTkButton(frm, text="Delete", width=140, fg_color="red", hover_color="#a30202", command=delete)
deleteBtn.grid(row=6, column=3, padx=6, pady=(30, 10), columnspan=2)

firstRecBtn = CTkButton(frm, text="FIRST", width=60, command=first)
firstRecBtn.grid(row=7, column=1, padx=(30, 10), pady=(5, 20))
nextRecBtn = CTkButton(frm, text="NEXT", width=60, command=next)
nextRecBtn.grid(row=7, column=2, padx=(13, 10), pady=(5, 20))
prevRecBtn = CTkButton(frm, text="PREV", width=60, command=prev)
prevRecBtn.grid(row=7, column=3, padx=(5, 0), pady=(5, 20))
lastRecBtn = CTkButton(frm, text="LAST", width=60, command=last)
lastRecBtn.grid(row=7, column=4, padx=(0, 6), pady=(5, 20))

app.after(100, load)
app.mainloop()