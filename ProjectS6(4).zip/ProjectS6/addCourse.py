from customtkinter import *
from PIL import Image
import mysql.connector
from CTkMessagebox import CTkMessagebox

'''
private void txtCourseName_KeyUp(object sender, KeyEventArgs e)
        {
            if (lblInfo.Text != "")
            {
                lblInfo.Text = "";
            }
            string sql = "select * from course where name='" + txtCourseName.Text.ToLower().Trim() + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Conn.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 0)
            {
                course = "y";
                txtCourseName.ForeColor = Color.Green;
            }
            else
            {
                course = "n";
                txtCourseName.ForeColor = Color.Tomato;
                lblInfo.ForeColor = Color.Tomato;
                lblInfo.Text = "Course Already Exists!";
            }
        }

'''

app = CTk()
app.grid_columnconfigure(0, weight=1)
app.after(0, lambda:app.state('zoomed'))
app.title("College")

db = mysql.connector.connect(host="localhost", user="root", password="", database="college_mgt")
mycursor = db.cursor()

def insert():
    name = txtnm.get()
    fees = txtfees.get()
    duration = cmbdur.get()

    if name.strip() and fees.strip() and duration != '-- SELECT DURATION --' and lbl1._text == "":
        sql = "INSERT INTO course(name, fees, duration) VALUES(%s, %s, %s)"
        values = (name, fees, duration)
        mycursor.execute(sql, values)
        db.commit()

        if mycursor.rowcount > 0:
            CTkMessagebox(frm, width=100, height=50, icon="check", icon_size=(20, 20), message="Record Inserted Successfully!")
            clear()
        else:
            CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Record Cannot Be Inserted!")
    else:
        CTkMessagebox(frm, width=100, height=50, icon="cancel", icon_size=(20, 20), message="Enter Valid Values!")

def clear():
    txtnm.delete(0, END)
    txtfees.delete(0, END)
    cmbdur.set("-- SELECT DURATION --")
    lbl1.configure(text="")

def keyup(event):
    course = txtnm.get()
    fees = txtfees.get()
    sql = "SELECT name FROM course WHERE name=%s"
    values = (course, )
    mycursor.execute(sql, values)
    res = mycursor.fetchall()

    if len(res) > 0:
        lbl1.configure(text="Course already exists!")
    elif not fees.isnumeric():
        lbl1.configure(text="Please enter only integer.")
    else:
        lbl1.configure(text="")

def keyupFees(event):
    fees = txtfees.get()

    if not fees.isnumeric():
        lbl1.configure(text="Please enter only integer.")
    else:
        lbl1.configure(text="")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabel = CTkLabel(app, image=imgtemp, text='')
imgLabel.place(relx=0.5, rely=0.5, anchor="center")

frm = CTkFrame(app, width=500, height=400, fg_color="transparent")
frm.place(relx=0.5, rely=0.5, anchor="center")

CTkLabel(frm, text="Enter Name", justify="left", anchor="w").grid(row=1, column=1, padx=(30, 12), pady=(30, 10), sticky="w")
txtnm = CTkEntry(frm, width=150)
txtnm.bind("<KeyRelease>", keyup)
txtnm.grid(row=1, column=2, pady=(30, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Enter Fees").grid(row=2, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
txtfees = CTkEntry(frm, width=150)
txtfees.bind("<KeyRelease>", keyup)
txtfees.grid(row=2, column=2, pady=(0, 10), padx=(10, 20), columnspan=2)

CTkLabel(frm, text="Select Duration").grid(row=3, column=1, padx=(30, 12), pady=(0, 10), sticky="w")
cmbdur = CTkComboBox(frm, width=150, values=['1 YEAR', '2 YEARS', '3 YEARS', '4 YEARS'])
cmbdur.set("-- SELECT DURATION --")
cmbdur.grid(row=3, column=2, padx=(10, 20), pady=(0, 20), columnspan=2)

lbl1 = CTkLabel(frm, text="", text_color="#fa3939")
lbl1.grid(row=4, column=1, padx=(10, 20), pady=(0, 10), columnspan=4)

CTkButton(frm, text="Insert", width=140, command=insert).grid(row=5, column=1, padx=(30, 6), pady=(10, 20))
CTkButton(frm, text="Clear", width=140, fg_color="red", hover_color="#a30202", command=clear).grid(row=5, column=2, padx=6, pady=(10, 20), columnspan=2)

app.mainloop()