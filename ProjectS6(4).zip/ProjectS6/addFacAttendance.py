from customtkinter import *
from PIL import Image

app = CTk()
# app.grid_columnconfigure(0, weight=1)
# app.after(0, lambda:app.state("zoomed"))
app.attributes("-zoomed", True)
app.title("College")

imgtemp = CTkImage(light_image=Image.open("mainback1.png"), size=(app.winfo_screenwidth(), app.winfo_screenheight()))
imgLabal = CTkLabel(app, image=imgtemp, text='')
imgLabal.place(relx=0.5, rely=0.5, anchor="center")

parent_frame = CTkFrame(app, width=800, height=600)
parent_frame.place(relx=0.5, rely=0.5, anchor="center")

frame1 = CTkFrame(parent_frame, width=266.67, height=600, fg_color="#4682B1")
frame1.grid(row=0, column=0, sticky="nswe")

CTkButton(frame1, width=100, height=40, fg_color="black", text="Add Attendance").grid(row=1, column=1, padx=10, pady=(20, 10))
CTkButton(frame1, width=100, height=40, fg_color="black", text="Modify Attendance").grid(row=2, column=1, padx=10, pady=(10, 10))

frame2 = CTkFrame(parent_frame, width=533.33, height=600, fg_color="#98AFC7")
frame2.grid(row=0, column=1, sticky="nswe")

app.mainloop()
